package com.dailyflow.app

import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var db: TaskDb
    private lateinit var list: LinearLayout
    private lateinit var stats: TextView
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=TaskDb(this); buildUi(); requestNotificationPermission() }
    private fun buildUi(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,28,24,16);setBackgroundColor(0xFFF6F7FB.toInt())}
        val title=TextView(this).apply{text="DailyFlow";textSize=30f;setTextColor(0xFF182033.toInt());setTypeface(null,1)}
        root.addView(title)
        stats=TextView(this).apply{textSize=16f;setTextColor(0xFF667085.toInt());setPadding(0,6,0,18)}; root.addView(stats)
        val add=Button(this).apply{text="+  Add Activity";setOnClickListener{addTask()}};root.addView(add)
        val scroll=ScrollView(this);list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root);refresh()
    }
    private fun refresh(){list.removeAllViews();val tasks=db.all();val done=tasks.count{it.done};stats.text="Today  •  $done / ${tasks.size} completed";tasks.forEach{t->
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(16,14,8,14);setBackgroundColor(0xFFFFFFFF.toInt())}
        val cb=CheckBox(this).apply{isChecked=t.done;setOnCheckedChangeListener{_,v->db.setDone(t.id,v);refresh()}}
        val txt=TextView(this).apply{text="${t.title}\n${if(t.time.isEmpty())"No reminder" else t.time}${if(t.repeat)"  •  Daily" else ""}";textSize=17f;setTextColor(0xFF182033.toInt())}
        row.addView(cb);row.addView(txt,LinearLayout.LayoutParams(0,-2,1f));val del=Button(this).apply{text="Delete";setOnClickListener{db.delete(t.id);refresh()}};row.addView(del);list.addView(row);val space=Space(this);list.addView(space,LinearLayout.LayoutParams(1,8))
    }}
    private fun addTask(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,10,30,0)}
        val name=EditText(this).apply{hint="Activity name"};box.addView(name)
        val time=EditText(this).apply{hint="Time (HH:mm), e.g. 08:30";inputType=2};box.addView(time)
        val daily=CheckBox(this).apply{text="Repeat every day"};box.addView(daily)
        AlertDialog.Builder(this).setTitle("New Activity").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->val n=name.text.toString().trim();if(n.isNotEmpty()){val id=db.add(n,time.text.toString().trim(),daily.isChecked);schedule(id,n,time.text.toString().trim(),daily.isChecked);refresh()}}.show()
    }
    private fun schedule(id:Long,title:String,time:String,daily:Boolean){if(time.length!=5)return;try{val p=time.split(":");val h=p[0].toInt();val m=p[1].toInt();val cal=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,h);set(Calendar.MINUTE,m);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis())add(Calendar.DATE,1)};val am=getSystemService(ALARM_SERVICE) as AlarmManager;val intent=Intent(this,ReminderReceiver::class.java).apply{putExtra("title",title);putExtra("id",id)};val pi=PendingIntent.getBroadcast(this,id.toInt(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));return};if(daily)am.setRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi) else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)}catch(_:Exception){}}
    private fun requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"),10)}
}

data class Task(val id:Long,val title:String,val time:String,val repeat:Boolean,val done:Boolean)

class TaskDb(c:Context){private val p=c.getSharedPreferences("dailyflow",0)
 fun all():List<Task>{val s=p.getStringSet("tasks",emptySet())?:emptySet();return s.mapNotNull{v->val a=v.split("|");if(a.size<5)null else Task(a[0].toLong(),a[1],a[2],a[3]=="1",a[4]=="1")}.sortedBy{it.time}}
 fun add(t:String,time:String,r:Boolean):Long{val id=System.currentTimeMillis();val s=p.getStringSet("tasks",emptySet())!!.toMutableSet();s.add("$id|${t.replace("|","")}|$time|${if(r)1 else 0}|0");p.edit().putStringSet("tasks",s).apply();return id}
 fun setDone(id:Long,v:Boolean){replace(id){it.copy(done=v)}}
 fun delete(id:Long){p.edit().putStringSet("tasks",all().filter{it.id!=id}.map{enc(it)}.toSet()).apply()}
 private fun replace(id:Long,f:(Task)->Task){p.edit().putStringSet("tasks",all().map{if(it.id==id)enc(f(it))else enc(it)}.toSet()).apply()}
 private fun enc(t:Task)="${t.id}|${t.title}|${t.time}|${if(t.repeat)1 else 0}|${if(t.done)1 else 0}"
}

class ReminderReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){val nm=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel("dailyflow","DailyFlow reminders",NotificationManager.IMPORTANCE_HIGH));val n=Notification.Builder(c,"dailyflow").setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("DailyFlow reminder").setContentText(i.getStringExtra("title")?:("Scheduled activity")).setAutoCancel(true).build();nm.notify((i.getLongExtra("id",System.currentTimeMillis())).toInt(),n)}}
