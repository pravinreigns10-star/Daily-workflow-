# DailyFlow — Native Android

Offline-first daily activity/checklist app for Android 10+.

Features: persistent local activities, dashboard completion count, scheduled local notifications, daily recurring reminders, completion and deletion.

## Build APK
Open this folder in Android Studio with Android SDK/Gradle available, then Build > Build APK(s). The APK will be in app/build/outputs/apk/debug/.

This environment cannot compile the APK because Android SDK/Gradle are not installed here.
